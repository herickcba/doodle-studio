# Os 14 arquétipos: chaves de spec

Todo slide é um objeto com `kind` e as chaves abaixo. Chaves comuns a todos:

| Chave | Tipo | Padrão | O quê |
|---|---|---|---|
| `kind` | string | — | obrigatório |
| `bg` | cor | `bege` | fundo do slide |
| `section` | string | `""` | rótulo do rodapé (vira caixa alta) |
| `footer` | bool | `true` | rodapé. Ignorado em `hero_cover` e `closing` |

Cor por nome: `azul` `rosa` `bege` `branco` `preto`. Quebra de linha explícita
com `\n` dentro da string.

`\n` **é decisão editorial**: use para controlar onde a manchete quebra. O resto
quebra sozinho pela largura da coluna.

---

## 1. hero_cover

Capa. **Exige fundo saturado** (azul ou rosa); qualquer outro valor é erro.

| Chave | Tipo | O quê |
|---|---|---|
| `eyebrow` | string | linha pequena acima, em Legenda 12 |
| `title` | string | o Statement 120 |
| `sub` | string | linha de apoio, em Destaque 44 |
| `style` | string | estilo do título, padrão `dsHero` |

Ponto final no título aciona a regra do ponto colorido.

## 2. chapter_divider

Abertura de bloco. Número, título e apoio formam **um grupo**, centralizado na
altura útil.

| Chave | Tipo | O quê |
|---|---|---|
| `number` | string | `"1."`, nunca `"01"` |
| `title` | string | Manchete 80 |
| `sub` | string | Texto 34, 2 colunas |

## 3. spec_page

Ficha técnica: pares rótulo/valor. Até 8 pares vão em 2 blocos de 2 colunas;
acima disso, 4 blocos de 1 coluna.

| Chave | Tipo | O quê |
|---|---|---|
| `eyebrow` | string | CAPS 12 |
| `title` | string | Título 60 |
| `intro` | string | Texto 34, 3 colunas |
| `rows` | lista de `[rótulo, valor]` | rótulo em CAPS 12, valor em Tópico 28 |

## 4. type_specimen

Uma amostra grande do estilo, no próprio corpo, mais a ficha.

| Chave | Tipo | O quê |
|---|---|---|
| `style_id` | string | id do estilo (`dsH1`, `dsCorpo`, …) |
| `sample` | string | o texto da amostra |
| `eyebrow` | string | padrão `"ESCALA TIPOGRÁFICA"` |

## 5. swatch_page

Uma cor por página: amostra de 2 colunas + hex, rgb e slot.

| Chave | Tipo | O quê |
|---|---|---|
| `palette` | nome de cor ou dict | `"rosa"` resolve sozinho |
| `index` | int | slot; deduzido do nome |

Amostra da mesma cor do fundo ganha contorno automático.

## 6. multi_card_grid

De 2 a 4 cards grandes. Mais que quatro é `card_grid_5`.

| Chave | Tipo | O quê |
|---|---|---|
| `eyebrow` | string | CAPS 12 |
| `title` | string | Título 60 |
| `card_bg` | cor | padrão: a alternativa válida ao fundo |
| `cards` | lista de `{kicker?, title, body}` | |

## 7. card_grid_5

Grade densa **com** caixa.

| Chave | Tipo | O quê |
|---|---|---|
| `title` | string | Título 60 |
| `intro` | string | Apoio 20, 3 colunas |
| `cols` | int | 2, 3, 4 ou 5 |
| `card_bg` | cor | |
| `items` | lista de `{kicker?, title, body}` | |

`kicker` numérico entra em Título 60 (é informação); textual entra em CAPS 12
(é etiqueta).

Padding: 20 com 3+ colunas, 40 com 2. Vão entre linhas = gutter (40).

## 8. grid_plain

A mesma grade **sem** caixa. Preferir quando o item é curto ou há 6+ itens.

Mesmas chaves do `card_grid_5`, sem `card_bg`.

Vão entre linhas = `max(80, 0,75 × altura do bloco)`, óptico.

## 9. zoned_content

Zona de argumento em cima, faixa de desdobramento embaixo, posicionadas como um
grupo só.

| Chave | Tipo | O quê |
|---|---|---|
| `eyebrow` | string | Chapéu 18 |
| `title` | string | Título 60 |
| `body` | string | Texto 34, 3 colunas |
| `items` | lista de `{title, body}` | 3 a 5. Menos não pede o layout |

## 10. stat_band

Variação do anterior, com números na faixa.

| Chave | Tipo | O quê |
|---|---|---|
| `eyebrow`, `title`, `body` | string | como acima |
| `stats` | lista de `{value, label}` | valor em Manchete 80 |

## 11. quote_side_image

Texto à esquerda (2 colunas), painel de cor à direita (2 colunas, altura útil
inteira). O painel carrega a citação, o número ou a amostra — não é decoração.

| Chave | Tipo | O quê |
|---|---|---|
| `eyebrow`, `title`, `body` | string | |
| `panel_bg` | cor | padrão azul |
| `panel_style` | string | estilo do texto do painel |
| `panel_text` | string | |

## 12. do_dont

Duas colunas de mesma largura. Cabeçalho em Subtítulo 34, colorido: azul no
"sim", rosa no "nunca". Os itens entram no **mesmo objeto** do cabeçalho.

| Chave | Tipo | O quê |
|---|---|---|
| `title`, `intro` | string | |
| `do_title` / `dont_title` | string | padrão `"Sim"` / `"Nunca"` |
| `do` / `dont` | lista de string | uma regra por item, verbo no infinitivo |

As duas colunas devem ter o mesmo número de itens e falar do mesmo assunto.

## 13. diagram_page

Esquema em escala **real**: o retângulo da página e a margem são proporcionais
de verdade, medidos dos mesmos tokens.

| Chave | Tipo | O quê |
|---|---|---|
| `title`, `intro` | string | |
| `legend` | lista de `[rótulo, valor]` | |
| `show_margin` | bool | padrão `true`, desenha a margem em rosa |
| `show_module` | bool | padrão `false`, desenha a régua do módulo |

## 14. closing

Fecho: um Statement ancorado na **margem de cima**, não centralizado.

| Chave | Tipo | O quê |
|---|---|---|
| `title` | string | Statement 120 |
| `bg` | cor | padrão azul |
