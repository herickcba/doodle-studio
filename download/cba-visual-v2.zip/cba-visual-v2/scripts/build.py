#!/usr/bin/env python3
"""build.py -- gera um PPTX no design system CBA visual 2, a partir de um spec.

    python3 scripts/build.py deck.json saida.pptx
    python3 scripts/build.py deck.json saida.pptx --no-audit

NAO existe arquivo-modelo. O deck nasce de uma apresentacao vazia e todo shape
sai dos tokens: nao ha' .pptx de referencia para copiar, nem XML institucional
para colar. Isso e' o que torna a skill portatil.

O spec e' JSON:

    {
      "slides": [
        {"kind": "hero_cover", "bg": "azul",
         "eyebrow": "CLIENTE  ·  2026",
         "title": "Uma frase que\\nmarca a pagina.",
         "sub": "Linha de apoio."},

        {"kind": "spec_page", "section": "ABERTURA",
         "title": "Titulo da pagina",
         "intro": "Paragrafo de argumento.",
         "rows": [["ROTULO", "Valor"], ["OUTRO", "Valor"]]}
      ]
    }

Cor por NOME (azul, rosa, bege, branco, preto) nas chaves bg, card_bg e
panel_bg. Hex tambem serve, desde que esteja na paleta.

Depois de gerar, AUDITA o proprio arquivo (scripts/audit.py) e sai com 1 se o
resultado ficou fora do sistema. Gerador que nao se confere e' gerador que
mente.
"""

from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from pptx import Presentation  # noqa: E402
from pptx.util import Pt  # noqa: E402

import audit as audit_mod  # noqa: E402
import layouts  # noqa: E402
import tokens as T  # noqa: E402

COLOR_BY_NAME = {c["name"]: c["hex"] for c in T.PALETTE.values()}
PAL_BY_NAME = {c["name"]: i for i, c in T.PALETTE.items()}
COLOR_KEYS = ("bg", "card_bg", "panel_bg")


def resolve_colors(slide):
    """Nome de cor -> hex, nas chaves que carregam cor."""
    out = dict(slide)
    for k in COLOR_KEYS:
        v = out.get(k)
        if isinstance(v, str) and v.lower() in COLOR_BY_NAME:
            out[k] = COLOR_BY_NAME[v.lower()]
    # swatch_page aceita "palette": "rosa" em vez do dict inteiro
    pal = out.get("palette")
    if isinstance(pal, str) and pal.lower() in PAL_BY_NAME:
        i = PAL_BY_NAME[pal.lower()]
        out["palette"] = T.PALETTE[i]
        out.setdefault("index", i)
    # rows e legend aceitam listas de 2 (JSON nao tem tupla)
    for k in ("rows", "legend"):
        if isinstance(out.get(k), list):
            out[k] = [tuple(r) if isinstance(r, list) else r for r in out[k]]
    return out


def build(spec, path):
    prs = Presentation()
    prs.slide_width = Pt(T.PAGE_W_PT)
    prs.slide_height = Pt(T.PAGE_H_PT)

    slides = spec["slides"] if isinstance(spec, dict) else spec
    for i, s in enumerate(slides, 1):
        if "kind" not in s:
            raise SystemExit("slide %d nao tem 'kind'. Arquetipos: %s"
                             % (i, ", ".join(sorted(layouts.BUILDERS))))
        try:
            layouts.build(prs, resolve_colors(s), i)
        except Exception as e:
            raise SystemExit("ERRO no slide %d (%s): %s" % (i, s["kind"], e))

    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)
    prs.save(path)
    return len(slides)


def main(argv):
    args = [a for a in argv[1:] if not a.startswith("--")]
    flags = {a for a in argv[1:] if a.startswith("--")}
    if len(args) < 2:
        raise SystemExit(__doc__)
    spec_path, out_path = args[0], args[1]

    with open(spec_path, encoding="utf-8") as fh:
        spec = json.load(fh)

    n = build(spec, out_path)
    print("== deck CBA visual 2 ==")
    print("   %s" % out_path)
    print("   %d slides" % n)
    print()
    if "--no-audit" in flags:
        return 0
    return audit_mod.report(out_path)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
