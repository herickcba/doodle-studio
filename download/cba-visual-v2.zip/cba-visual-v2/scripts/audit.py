#!/usr/bin/env python3
"""audit.py -- confere um PPTX contra o design system CBA visual 2.

    python3 scripts/audit.py deck.pptx

Le o arquivo final e mede o que esta' la', nao o que o codigo pretendia. E'
proposital: um gerador pode acertar a intencao e errar o resultado, e foi
exatamente o que aconteceu nas primeiras versoes do sistema.

Confere:
  tokens      fonte, corpo, cor e entrelinha de cada run
  transbordo  mede o texto com a fonte real e compara com a caixa
  margem      nada abaixo da margem inferior, nada encostado no rodape
  caixa       card esticado, card da cor do fundo sem contorno
  escrita     travessao e hifen duplo
  ocupacao    slide vazio demais ou lotado (aviso)

Sai com 1 se houver erro. Avisos nao bloqueiam.
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from pptx import Presentation  # noqa: E402

import measure  # noqa: E402
import tokens as T  # noqa: E402

# Mesma derivacao do layouts.py: a altura do rodape e' a linha desenhada da
# Legenda 12. Duplicar o numero a mao foi o que fez o auditor deixar de
# reconhecer o rodape e acusar 8 erros que nao existiam.
FOOTER_H = measure.line_height(T.STYLE_BY_ID["dsLegenda12"])
FOOTER_CLEARANCE = T.SPACING[3]
CONTENT_END = T.CONTENT_BOTTOM_PT - FOOTER_H - FOOTER_CLEARANCE
FOOTER_Y = T.CONTENT_BOTTOM_PT - FOOTER_H


def audit(path):
    """Devolve (n_slides, n_runs, erros, avisos)."""
    prs = Presentation(path)
    sizes_ok = {float(s) for s in T.ALLOWED_SIZES}
    hexes_ok = {h.upper() for h in T.ALLOWED_HEX}
    ents_ok = {round(s["ent"], 3) for s in T.STYLES}
    by_size = {}
    for st in T.STYLES:
        by_size.setdefault((st["size"], bool(st["bold"]), round(st["ent"], 3)), st)

    errs, warns = [], []
    runs = 0
    for n, slide in enumerate(prs.slides, 1):
        content_bottom = 0.0
        content_shapes, statement_only = 0, True
        try:
            slide_bg = str(slide.background.fill.fore_color.rgb).upper()
        except Exception:
            slide_bg = None

        for shape in slide.shapes:
            # ---- card da cor do fundo nao e' card. So' vale com contorno.
            if slide_bg and not (shape.has_text_frame
                                 and shape.text_frame.text.strip()):
                try:
                    fill_hex = str(shape.fill.fore_color.rgb).upper()
                except Exception:
                    fill_hex = None
                if fill_hex == slide_bg:
                    outlined = False
                    try:
                        outlined = shape.line.color.rgb is not None
                    except Exception:
                        pass
                    if not outlined:
                        errs.append("slide %d: forma da mesma cor do fundo (%s) "
                                    "e sem contorno" % (n, fill_hex))

            # ---- caixa esticada e caixa fora da margem
            if (not shape.has_text_frame or not shape.text_frame.text.strip()) \
                    and shape.height and shape.width:
                bh = shape.height / 12700
                tallest = 0.0
                for other in slide.shapes:
                    if other is shape or not other.has_text_frame:
                        continue
                    if not other.text_frame.text.strip():
                        continue
                    ox, oy = other.left / 12700, other.top / 12700
                    if (shape.left / 12700 <= ox
                            <= shape.left / 12700 + shape.width / 12700
                            and shape.top / 12700 <= oy <= shape.top / 12700 + bh):
                        tallest = max(tallest, oy + other.height / 12700
                                      - shape.top / 12700)
                if tallest > 0 and bh > tallest * T.BOX_STRETCH_MAX + T.BOX_PAD_PT:
                    errs.append("slide %d: caixa esticada (%.0fpt de altura para "
                                "%.0fpt de conteudo)" % (n, bh, tallest))
                bbot = (shape.top + shape.height) / 12700
                if bbot > T.CONTENT_BOTTOM_PT + 1:
                    errs.append("slide %d: caixa passa %.0fpt da margem inferior"
                                % (n, bbot - T.CONTENT_BOTTOM_PT))

            if not shape.has_text_frame:
                continue

            # ---- transbordo, PARAGRAFO A PARAGRAFO (estilos mistos num card)
            txt = shape.text_frame.text
            if txt.strip() and shape.width and shape.height:
                tf = shape.text_frame
                inner_w = shape.width / 12700
                inner_h = shape.height / 12700
                try:
                    inner_w -= (tf.margin_left + tf.margin_right) / 12700
                    inner_h -= (tf.margin_top + tf.margin_bottom) / 12700
                except Exception:
                    pass
                # A correcao "a primeira linha ocupa o corpo inteiro mesmo com
                # entrelinha menor que 1" vale para a primeira linha do QUADRO,
                # nao de cada paragrafo. Aplicar em todos inflava o Statement
                # 120 (0,8x) em 7pt e acusava transbordo que nao existe.
                need, known, first = 0.0, True, True
                for para in tf.paragraphs:
                    r0 = para.runs[0] if para.runs else None
                    if r0 is None or not r0.font.size or not para.line_spacing:
                        continue
                    st = by_size.get((r0.font.size.pt, bool(r0.font.bold),
                                      round(float(para.line_spacing), 3)))
                    if not st:
                        known = False
                        break
                    ptxt = "".join(r.text for r in para.runs)
                    if first:
                        need += measure.block_height(ptxt, st, inner_w)
                        first = False
                    else:
                        need += measure.line_height(st) * measure.wrap_lines(
                            ptxt, st["size"], bool(st["bold"]), inner_w,
                            caps=bool(st.get("caps")),
                            spacing_pt=float(st.get("spacing") or 0))
                    if para.space_before:
                        need += para.space_before.pt
                    if para.space_after:
                        need += para.space_after.pt
                if known and need > inner_h + 2:
                    errs.append(
                        "slide %d: texto transborda %.0fpt (precisa %.0f, "
                        "caixa %.0f) em %r"
                        % (n, need - inner_h, need, inner_h,
                           txt[:32].replace("\n", " ")))

            # ---- margem inferior e folga do rodape
            if txt.strip():
                bottom = (shape.top + shape.height) / 12700
                is_footer = abs(shape.top / 12700 - FOOTER_Y) < 2
                if not is_footer:
                    content_bottom = max(content_bottom, bottom)
                    content_shapes += 1
                    r0 = next((r for p in shape.text_frame.paragraphs
                               for r in p.runs if r.text.strip()), None)
                    if r0 is None or not r0.font.size or r0.font.size.pt != 120:
                        statement_only = False
                if bottom > T.CONTENT_BOTTOM_PT + 1:
                    errs.append("slide %d: passa %.0fpt da margem inferior: %r"
                                % (n, bottom - T.CONTENT_BOTTOM_PT,
                                   txt[:34].replace("\n", " ")))
                elif not is_footer and bottom > CONTENT_END + 1:
                    errs.append("slide %d: encosta na tag do rodape (%.0fpt de "
                                "folga, minimo %.0f): %r"
                                % (n, T.CONTENT_BOTTOM_PT - FOOTER_H - bottom,
                                   FOOTER_CLEARANCE,
                                   txt[:34].replace("\n", " ")))

            for p in shape.text_frame.paragraphs:
                if p.line_spacing is not None:
                    ls = round(float(p.line_spacing), 3)
                    if ls not in ents_ok:
                        errs.append("slide %d: entrelinha %.3f fora da tabela"
                                    % (n, ls))
                for r in p.runs:
                    if not r.text.strip():
                        continue
                    runs += 1
                    if "--" in r.text or "—" in r.text or "–" in r.text:
                        errs.append("slide %d: travessao ou hifen duplo em %r"
                                    % (n, r.text[:44]))
                    f = r.font
                    if f.name != T.FONT:
                        errs.append("slide %d: fonte %r em %r"
                                    % (n, f.name, r.text[:24]))
                    if f.size is None or f.size.pt not in sizes_ok:
                        errs.append("slide %d: corpo %s fora da escala em %r"
                                    % (n, f.size.pt if f.size else None,
                                       r.text[:24]))
                    try:
                        h = str(f.color.rgb).upper()
                    except Exception:
                        h = None
                    if h and h not in hexes_ok:
                        errs.append("slide %d: cor #%s fora da paleta em %r"
                                    % (n, h, r.text[:24]))

        # ---- ocupacao do canvas. Capa e fecho sao um Statement so' ancorado
        # no topo: o espaco negativo E' o arquetipo, nao um defeito.
        used = (content_bottom - T.MARGIN_TOP_PT) / T.CONTENT_H_PT
        if content_shapes == 1 and statement_only:
            pass
        elif 0 < used < T.CANVAS_FILL_MIN:
            warns.append("slide %d: conteudo ocupa so' %.0f%% da altura util. "
                         "Vazio demais." % (n, used * 100))
        elif used > T.CANVAS_FILL_MAX:
            warns.append("slide %d: conteudo ocupa %.0f%% da altura util. "
                         "Lotado: cortar texto ou dividir em dois slides."
                         % (n, used * 100))
    return len(prs.slides), runs, errs, warns


def report(path, quiet=False):
    slides, runs, errs, warns = audit(path)
    if not quiet:
        print("== auditoria: %s ==" % os.path.basename(path))
        print("   %d slides, %d runs de texto conferidas" % (slides, runs))
    if warns:
        print()
        print("AVISOS (%d):" % len(warns))
        for w in warns[:20]:
            print("  - " + w)
        if len(warns) > 20:
            print("  ... e mais %d" % (len(warns) - 20))
    if errs:
        print()
        print("FORA DO SISTEMA (%d):" % len(errs))
        for e in errs[:40]:
            print("  - " + e)
        if len(errs) > 40:
            print("  ... e mais %d" % (len(errs) - 40))
        return 1
    if not quiet:
        print("   OK: nada fora dos tokens.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    sys.exit(report(sys.argv[1]))
