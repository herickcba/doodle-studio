---
name: cba-visual-v2
description: |
  Sistema visual CBA B+G 2 (Avenir Next, rosa/azul sobre bege, página
  1583,13×890,63pt, grade de 4 colunas, 14 arquétipos). Use sempre que o
  usuário pedir para criar ou revisar um deck no padrão CBA, mencionar o design
  system CBA, pedir auditoria de um PPTX contra o padrão, ou quando for aplicar
  a marca em outra mídia (web, impresso, social) e precisar dos tokens.

  Também vale para CRÍTICA de layout: as regras de composição aqui são
  específicas o bastante para apontar o que está errado num slide, e não só
  para gerar um novo.

  NÃO depende de nenhum arquivo PowerPoint de referência. O deck nasce de uma
  apresentação vazia; todo shape sai dos tokens. Não procure template.
---

# CBA visual v2

> **Regras: 2.3** · Avenir Next · rosa `FD5E6D` / azul `436AE1` sobre bege
> `EEECE6` · página 1583,13 × 890,63pt · margem 60 · módulo 20 · raio 20 ·
> 4 colunas · 14 estilos · 14 arquétipos

O **v2** do nome é a geração do sistema e não muda. O número que muda é o das
regras, versionado aqui dentro: v2 é a geração, 2.3 é o estado dela hoje.
O histórico de cada mudança está em `reference/rules.md` e no git do
repositório Doodle Maker.

Sistema visual da CBA B+G. Ele é a mesma coisa que a faixa CBA Studio aplica
com um clique dentro do PowerPoint: os tokens daqui são espelho do
`SetDefaults` do add-in, não uma interpretação dele.

**Sem arquivo-modelo.** A skill anterior (`cba-bg-design-system-v3`) carregava um
`wrapper.pptx` e XMLs institucionais extraídos da máquina do autor, e não rodava
sem eles. Esta gera do zero: `Presentation()` vazia, tudo desenhado a partir dos
tokens. A única dependência externa é a fonte Avenir Next instalada, e mesmo ela
tem fallback (mede pior, não quebra).

## Como usar

**Para gerar um deck**, escreva um spec JSON e rode:

```bash
python3 scripts/build.py deck.json saida.pptx
```

O `build.py` audita o próprio resultado e sai com erro se ficou fora do sistema.

**Para auditar um deck existente:**

```bash
python3 scripts/audit.py deck-do-cliente.pptx
```

**Para criticar um layout sem rodar nada**, leia as regras abaixo e
`reference/rules.md`. Elas são autossuficientes: dá para revisar um slide, um
site ou um post lendo só este arquivo.

`examples/reference_deck.py` é o spec das 88 páginas da documentação do próprio
sistema. Serve de exemplo canônico de cada arquétipo.

---

## 1. Página e grade

| | pt | px @1080 | cm |
|---|---|---|---|
| Página | 1583,13 × 890,63 | 1920 × 1080 | 55,8 × 31,4 |
| Margem (4 lados) | 60 | 72,8 | 2,12 |
| Módulo | 20 | 24,3 | 0,71 |
| Raio | 20 | 24,3 | 0,71 |
| Gutter | 40 (= 2 × raio) | 48,5 | 1,41 |
| Coluna (1 de 4) | 335,78 | 407,4 | 11,84 |

Área útil: 1463,13 × 770,63pt. **Todo bloco ocupa 1, 2, 3 ou 4 colunas** —
nunca uma largura escolhida no olho. Larguras válidas: 335,78 · 711,57 ·
1087,35 · 1463,13.

16:9 **customizado**, não o 16:9 padrão do PowerPoint. Deck em outro formato
entra distorcido.

## 2. Paleta

| Slot | Nome | Hex | Papel |
|---|---|---|---|
| pal0 | rosa | `#FD5E6D` | Cor de tipo 1: statements, títulos, chapéus, números |
| pal1 | azul | `#436AE1` | Cor de tipo 2: corpo, tópicos, legendas, manchetes |
| pal2 | bege | `#EEECE6` | Fundo padrão. **Nunca é cor de tipo** |
| pal3 | branco | `#FFFFFF` | Fundo claro e tipo sobre fundo saturado |
| pal4 | preto | `#000000` | Reserva. Não usar em tipo da marca |

Fundos permitidos: bege, branco, azul, rosa. Nada mais, nunca gradiente.

> O rosa correto é `FD5E6D`. A landing e a skill v3 usam `FC5E6D` — um dígito de
> diferença, invisível a olho e detectável em auditoria. Se encontrar `FC5E6D`,
> corrija.

## 3. Escala tipográfica

**Avenir Next**, 14 estilos. Fora desta tabela não existe corpo válido.

| Estilo | pt | Peso | Cor | Entrelinha | Uso |
|---|---|---|---|---|---|
| Big Number 250 | 250 | Bold | rosa | 1,0 | O número que carrega a página. Um por slide |
| Statement 120 | 120 | Bold | rosa | 0,8 | A frase-manifesto. Ponto final azul |
| Manchete 80 | 80 | Bold | azul | 0,9 | Abertura de capítulo |
| Título 60 | 60 | Bold | rosa | 0,9 | Título de página |
| Destaque 44 | 44 | Regular | azul | 1,15 | Corpo de destaque, statement curto |
| Subtítulo 34 | 34 | Bold | rosa | 0,95 | Subtítulo abaixo do título |
| Texto 34 | 34 | Regular | azul | 1,3 | Texto corrido grande, parágrafo de argumento |
| Tópico 28 | 28 | Bold | azul | 1,0 | Título de tópico ou de card |
| Texto 24 | 24 | Regular | azul | 1,0 | Texto corrido. Padrão de toda caixa nova |
| Apoio 20 | 20 | Regular | azul | 1,3 | Apoio em pilares e colunas |
| Chapéu 18 | 18 | Bold | rosa | 1,0 | Chapéu acima do título |
| Texto 15 | 15 | Regular | azul | 1,3 | Texto corrido pequeno, slides densos |
| Legenda 12 | 12 | Bold | azul | 1,3 | Legendas, notas, fontes |
| CAPS 12 | 12 | Bold | azul | 1,0 | Rótulo em caixa alta, +3pt entre letras |

**A entrelinha pertence ao ESTILO, não ao corpo.** Dois pares dividem o mesmo
corpo e divergem: Subtítulo 34 × Texto 34, Legenda 12 × CAPS 12.

Quanto maior o corpo, mais apertada a linha. Em 250pt o espaço entre linhas já é
enorme em valor absoluto e o multiplicador comprime; em 12pt é o inverso.

Os 14 existem na faixa e aqui. O **Texto 34** entrou na faixa na v1.6.0.

## 4. As duas regras que ninguém adivinha

Estas duas custaram três versões para aparecer. São a diferença entre um layout
que "está no grid" e um que parece certo.

### A altura da linha não é corpo × entrelinha

O PowerPoint aplica a entrelinha percentual sobre a altura **natural** da linha
da fonte, que na Avenir Next é 1,366 × o corpo. Medido no próprio PowerPoint
(pedindo que ele ajustasse a caixa ao texto): uma linha de 250pt com entrelinha
1,0 ocupa **302,9pt**.

```
altura da linha = corpo × entrelinha × 1,2116
base da letra   = 73,2% da altura da linha
```

Medir sem esse fator subestima toda caixa em ~21%. É a causa clássica de texto
encostado no fundo de um card e de padding inferior menor que o superior.

### O vão é ÓPTICO, não numérico

O gap se mede da **base da letra de cima** até o topo da caixa de baixo. A caixa
de uma linha desce até o pé do descendente, mas um número, uma caixa alta ou uma
palavra sem `g` nem `p` param na base da letra. Essa sobra já é espaço branco, e
cresce com o corpo:

| Estilo | Caixa de 1 linha | Sobra abaixo da letra |
|---|---|---|
| Big Number 250 | 302,9 pt | **81,2 pt** |
| Título 60 | 65,4 pt | 17,5 pt |
| Tópico 28 | 33,9 pt | 9,1 pt |
| CAPS 12 | 14,5 pt | 3,9 pt |

Então: escolha o degrau óptico e **desconte a sobra**. Um par número/título com
20 ópticos vira 2,5pt desenhados sob um Título 60 e 18,6pt sob um CAPS 12 —
valores diferentes que produzem o mesmo espaço visto. Sob um Big Number, um
degrau de 40 vira **−41pt** e as caixas se sobrepõem: é o resultado certo, elas
se sobrepõem no vazio.

Aplicar o degrau literalmente é o erro mais comum, e ele aparece justamente onde
o corpo é grande.

## 5. Escala vertical

| Degrau | pt | Quando |
|---|---|---|
| 1× | 20 | Amarra rótulo ao valor, título ao apoio |
| 2× | 40 | Entre itens de lista, entre linhas de grade **com card** |
| 3× | 60 | Depois do cabeçalho, antes do conteúdo |
| 4× | 80 | Entre blocos de assunto diferente |

Só estes quatro. O degrau vem da **relação** entre os blocos, nunca do espaço
que sobrou na página.

**Grade sem card** é o caso especial: não há borda, é o espaço que agrupa, e o
vão cresce com o bloco.

```
vão óptico entre linhas = max(80, 0,75 × altura do bloco)
```

## 6. Composição

**Altura de caixa vem do conteúdo.** Card = padding + o maior conteúdo do grupo
+ padding. Todos os cards de uma linha têm a mesma altura, dada pelo mais alto.
Card mais vazio que o vizinho é resultado correto; texto encostado no fundo, não.

**Padding do card sai do tamanho dele:**

| Cards na linha | Padding |
|---|---|
| 3 ou mais (grade) | 20 pt |
| 1 ou 2 (card grande) e painéis | 40 pt |

Card de uma coluna com 40 de padding vira moldura.

**Conteúdo ancorado no meio da forma**, para a folga sobrar igual em cima e
embaixo.

**O texto mora DENTRO da forma.** Card é uma forma só, com parágrafos de estilos
diferentes. Caixa de texto sobreposta a um retângulo obriga quem edita a mexer
em dois objetos e a mantê-los alinhados na mão.

**Não esticar para preencher.** Grupo menor que o espaço disponível
**centraliza** no que sobra. Aumentar o vão até chegar no rodapé desconecta os
blocos em vez de dar ritmo.

**Lista é uma caixa só**: itens de mesma função viram parágrafos de um bloco,
não uma caixa por item.

**Texto que não cabe: edite o texto, não a escala.** Se a intenção era Destaque
44, o slide continua em Destaque 44 e a frase encurta. Descer de degrau quebra a
comparação com os outros slides do mesmo arquétipo.

**Folga do rodapé**: 60pt livres acima da tag de seção. Nada encosta nela.

**Ocupação saudável**: entre 35% e 95% da altura útil. Abaixo, distribua em
zonas; acima, corte texto ou divida em dois slides. Capa e fecho são exceção:
são um Statement só ancorado no topo, e o espaço negativo é o arquétipo.

**Card nunca é da cor do fundo.** Sobre bege o card é branco; sobre branco,
bege; sobre cor, branco. Retângulo da cor do fundo só existe com contorno, e só
quando a amostra É aquela cor.

**Numeração `1.` `2.` `3.`**, nunca `01`.

## 7. Comportamento do tipo

**Sobre fundo saturado (azul ou rosa), todo tipo é branco.** Não é escolha de
quem monta o slide: rosa sobre rosa some, e azul sobre rosa não é o que a marca
faz.

**Contraste automático em fundo claro:** se a cor do tipo for exatamente a cor
do fundo, o tipo vira branco. O fundo relevante é, nesta ordem: o da própria
forma, o do grupo que a contém, o do slide. Uma forma sólida cobrindo a página
conta como fundo.

**Ponto final colorido:** o Statement 120 pinta o ponto final de azul. Só o
ponto, e só se a frase terminar em ponto. Sobre azul o texto vira branco e o
ponto vira rosa; sobre rosa, o ponto vira azul. É o único estilo com
comportamento próprio.

**Caixa alta** só no CAPS 12, com 3pt entre letras. Nunca simular caixa alta
digitando em maiúscula noutro estilo.

## 8. Escrita

- Sem travessão (—) e **sem hífen duplo** (`--`). Reescreva com vírgula, ponto
  ou dois-pontos.
- Sem frase-comentário solta no rodapé do slide.
- Sem "nota:", "atenção:" pendurados no fim.
- Uma tese por slide. Se há duas, são dois slides.

## 9. Anti-vícios

O sistema **nunca** emite: sombra, gradiente, linha decorativa, borda que não
seja funcional, ícone fora do catálogo, corpo fora da escala, entrelinha fora da
tabela, cor fora da paleta, caixa esticada até o rodapé, texto sobreposto a
retângulo em vez de dentro dele, `01` como numeração.

## 10. Os 14 arquétipos

Ver `reference/archetypes.md` para as chaves que cada um aceita.

| # | kind | Quando |
|---|---|---|
| 1 | `hero_cover` | Capa. Fundo saturado obrigatório |
| 2 | `chapter_divider` | Abertura de bloco. Big Number + Manchete |
| 3 | `spec_page` | Título, intro e pares rótulo/valor |
| 4 | `type_specimen` | Amostra de um estilo + ficha técnica |
| 5 | `swatch_page` | Uma cor por página |
| 6 | `multi_card_grid` | 2 a 4 cards grandes |
| 7 | `card_grid_5` | Grade densa com caixa |
| 8 | `grid_plain` | A mesma grade sem caixa, item curto |
| 9 | `zoned_content` | Zona de argumento + faixa de desdobramento |
| 10 | `stat_band` | Zona + faixa de números |
| 11 | `quote_side_image` | Texto à esquerda, painel de cor à direita |
| 12 | `do_dont` | Duas colunas, sim e nunca |
| 13 | `diagram_page` | Esquema em escala real |
| 14 | `closing` | Fecho. Statement ancorado no topo |

Fora deles é composição nova, e composição nova pede revisão explícita.

## 11. Fora do PowerPoint

Os tokens atravessam mídia. A ponte é a altura: **1080px = 890,63pt**, logo
**1pt = 1,2126px**.

Para web, o corpo em px é `pt × 1,2126` e a entrelinha é a mesma (é
multiplicador, não valor absoluto). Margem 60pt = 72,8px; módulo 20pt = 24,3px;
raio 20pt = 24,3px.

A regra do vão óptico vale igual em CSS, e ali é ainda mais visível porque
`line-height` cria o mesmo espaço vazio acima e abaixo do texto.

## 12. Faixa e sistema, alinhados

Desde a **v1.6.0** do add-in não há divergência entre a faixa e este documento:
as linhas-guia usam a margem de 60pt, o raio é 20pt como valor visual constante
(antes era uma fração da altura da página) e o Texto 34 existe nos dois lados.

Se mexer no `.bas`, o `check-tokens.py` **bloqueia** qualquer divergência de
estilo, cor, raio ou margem. Ele não avisa mais: reprova.

## 13. Arquivos desta skill

```
cba-visual-v2/
├── SKILL.md                    este arquivo: o sistema inteiro em texto
├── reference/
│   ├── rules.md                as regras completas, com o porquê de cada uma
│   └── archetypes.md           as chaves de spec de cada arquétipo
├── scripts/
│   ├── tokens.py               a tabela: cores, estilos, grade
│   ├── measure.py              mede texto com a fonte real; altura de linha
│   ├── layouts.py              os 14 construtores; o vão óptico mora aqui
│   ├── build.py                CLI: spec JSON -> PPTX (audita o resultado)
│   └── audit.py                CLI: PPTX -> relatório de conformidade
└── examples/
    ├── minimal.json            spec curto, para começar
    └── reference_deck.py       o spec das 88 páginas da documentação
```

**Fonte da verdade a montante:** `SetDefaults` em
`v3-powerpoint-addin/assets/BG-DoodleStudio.bas`, no repositório Doodle Maker.
Se os dois divergirem, o `.bas` ganha — exceto nas três dívidas acima, onde o
sistema já decidiu e a faixa é que está atrasada.
